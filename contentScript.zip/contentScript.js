function logAppInitializationState() {
  if (window.APP_INITIALIZATION_STATE && window.APP_INITIALIZATION_STATE[3] && window.APP_INITIALIZATION_STATE[3][2]) {
    let data = window.APP_INITIALIZATION_STATE[3][2];
    const prefixToRemove = ')]}\'';

    if (data.startsWith(prefixToRemove)) {
      data = data.slice(prefixToRemove.length);
    }

    const url = 'https://ranklocal.in/receiver.php'; // Replace with the URL of your receiver.php script

    const xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          // Create a new <div> element to display the received data
          const div = document.createElement('div');
          div.innerHTML = xhr.responseText;
          div.style.position = 'absolute';
          div.style.top = '10px';
          div.style.right = '10px';
          div.style.zIndex = '99999'; // Adjust the z-index value to make it the top layer
          div.style.backgroundColor = '#fff';
          div.style.padding = '10px';
          div.style.border = '1px solid #ccc';
          div.style.maxWidth = '300px';

          // Append the <div> to the body of the Maps page
          document.body.appendChild(div);
        } else {
          console.log('Failed to send data.');
        }
      }
    };

    const params = 'data=' + encodeURIComponent(data); // URL-encode the data
    xhr.send(params);
  }
}

// Inject the logAppInitializationState function into the web page
const script = document.createElement('script');
script.textContent = `(${logAppInitializationState.toString()})();`;
(document.head || document.documentElement).appendChild(script);
script.remove();
