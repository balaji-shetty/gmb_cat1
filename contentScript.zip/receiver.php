<!DOCTYPE html>
<html>
<head>
    <title>Received Data</title>
</head>
<body>
    <h1>Received Data</h1>

    <?php
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Allow-Headers: Content-Type");

    // Get the data from the POST request
    $data = $_POST['data'];

    // URL-decode the data
    $data = urldecode($data);

    // Parse the data as JSON
    $parsedData = json_decode($data, true);

    // Check if JSON decoding was successful
    if ($parsedData === null) {
        echo '<p>Invalid JSON</p>';
    } else {
        // Assuming $parsedData is already available
        
        function fetchNestedData($array, $location) {
            $locationArr = explode('][', trim($location, '[]'));
            $value = $array;

            foreach ($locationArr as $index) {
                $index = str_replace(['[', ']'], '', $index);
                if (isset($value[$index])) {
                    $value = $value[$index];
                } else {
                    return null;
                }
            }

            return $value;
        }
        
        $baseLocation = '[[0][1][__BLOCK__][14][13][__ITERATION__]]';

        // Initialize an empty array to store category occurrences
        $categoryOccurrences = [];

        for ($block = 1; $block <= 20; $block++) {
            for ($iteration = 0; $iteration < 10; $iteration++) {
                $location = str_replace('__BLOCK__', $block, $baseLocation);
                $location = str_replace('__ITERATION__', $iteration, $location);

                $value = fetchNestedData($parsedData, $location);

                if ($value !== null) {
                    // Store the category occurrence
                    if (isset($categoryOccurrences[$value])) {
                        $categoryOccurrences[$value]++;
                    } else {
                        $categoryOccurrences[$value] = 1;
                    }
                    
                  //  echo "<p>[$location] => $value</p>";
                }
            }
        }

        // Sort the category occurrences in descending order
        arsort($categoryOccurrences);

        // Display the category occurrences
        echo "<h2>Category Occurrences:</h2>";
        foreach ($categoryOccurrences as $category => $occurrences) {
            echo "\n Category: $category | Occurrences: $occurrences";
        }
    }
    ?>
</body>
</html>
